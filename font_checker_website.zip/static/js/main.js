// Font Checker Web Application - Frontend JavaScript
// This file connects the HTML interface to the Flask backend

document.addEventListener('DOMContentLoaded', function() {
    // File input change handler
    document.getElementById('file-input').addEventListener('change', function(e) {
        if (e.target.files.length > 0) {
            const file = e.target.files[0];
            if (file.name.endsWith('.docx')) {
                uploadFile(file);
            } else {
                alert('Please upload a .docx file');
            }
        }
    });
    
    // Drag and drop functionality
    const uploadArea = document.getElementById('upload-area');
    
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, unhighlight, false);
    });
    
    function highlight() {
        uploadArea.classList.add('bg-light');
    }
    
    function unhighlight() {
        uploadArea.classList.remove('bg-light');
    }
    
    uploadArea.addEventListener('drop', handleDrop, false);
    
    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (files.length > 0) {
            const file = files[0];
            if (file.name.endsWith('.docx')) {
                uploadFile(file);
            } else {
                alert('Please upload a .docx file');
            }
        }
    }
    
    // Store file path for later use
    let currentFilePath = null;
    
    // Upload and check file
    function uploadFile(file) {
        // Show loading spinner
        document.getElementById('loading').style.display = 'block';
        
        // Hide result box if it was previously shown
        document.getElementById('result-box').classList.add('d-none');
        
        // Create form data
        const formData = new FormData();
        formData.append('file', file);
        
        // Send file to server
        fetch('/api/check', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Hide loading spinner
            document.getElementById('loading').style.display = 'none';
            
            // Show results
            const resultBox = document.getElementById('result-box');
            resultBox.classList.remove('d-none');
            
            if (data.success) {
                // Store file path for fix operation
                currentFilePath = data.file_path;
                
                if (data.meets_requirements) {
                    resultBox.classList.add('result-success');
                    resultBox.classList.remove('result-error');
                    
                    let resultContent = `
                        <div class="alert alert-success">
                            <strong>✓ Document meets the requirement:</strong> Times New Roman, size 14
                        </div>
                        <p>No issues found. Your document is correctly formatted with Times New Roman size 14.</p>
                    `;
                    
                    document.getElementById('result-content').innerHTML = resultContent;
                    document.getElementById('fix-section').classList.add('d-none');
                } else {
                    resultBox.classList.add('result-error');
                    resultBox.classList.remove('result-success');
                    
                    let resultContent = `
                        <div class="alert alert-danger">
                            <strong>✗ Document does not meet the requirement:</strong> Times New Roman, size 14
                        </div>
                        <p>Found ${data.issue_count} issues:</p>
                        <ul class="issue-list">
                    `;
                    
                    // Add issues to list
                    data.issues.forEach(issue => {
                        resultContent += `<li>${issue}</li>`;
                    });
                    
                    resultContent += `</ul>`;
                    
                    document.getElementById('result-content').innerHTML = resultContent;
                    document.getElementById('fix-section').classList.remove('d-none');
                    
                    // Add event listener for fix button
                    document.getElementById('fix-button').onclick = function() {
                        fixDocument(currentFilePath);
                    };
                }
            } else {
                // Show error
                resultBox.classList.add('result-error');
                resultBox.classList.remove('result-success');
                
                let resultContent = `
                    <div class="alert alert-danger">
                        <strong>Error:</strong> ${data.message}
                    </div>
                `;
                
                document.getElementById('result-content').innerHTML = resultContent;
                document.getElementById('fix-section').classList.add('d-none');
            }
        })
        .catch(error => {
            // Hide loading spinner
            document.getElementById('loading').style.display = 'none';
            
            // Show error
            const resultBox = document.getElementById('result-box');
            resultBox.classList.remove('d-none');
            resultBox.classList.add('result-error');
            resultBox.classList.remove('result-success');
            
            let resultContent = `
                <div class="alert alert-danger">
                    <strong>Error:</strong> An error occurred while processing your document.
                </div>
                <p>Please try again later.</p>
            `;
            
            document.getElementById('result-content').innerHTML = resultContent;
            document.getElementById('fix-section').classList.add('d-none');
            
            console.error('Error:', error);
        });
    }
    
    // Fix document
    function fixDocument(filePath) {
        // Show loading spinner
        document.getElementById('loading').style.display = 'block';
        document.getElementById('result-box').classList.add('d-none');
        
        // Send fix request to server
        fetch('/api/fix', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                file_path: filePath
            })
        })
        .then(response => response.json())
        .then(data => {
            // Hide loading spinner
            document.getElementById('loading').style.display = 'none';
            
            // Show results
            const resultBox = document.getElementById('result-box');
            resultBox.classList.remove('d-none');
            
            if (data.success) {
                resultBox.classList.add('result-success');
                resultBox.classList.remove('result-error');
                
                let resultContent = `
                    <div class="alert alert-success">
                        <strong>✓ Document has been fixed!</strong>
                    </div>
                    <p>Fixed ${data.fixed_issues_count} issues. Your document now uses Times New Roman size 14 throughout.</p>
                    <a href="/api/download/${data.download_id}" class="btn btn-primary mt-3">Download Fixed Document</a>
                `;
                
                document.getElementById('result-content').innerHTML = resultContent;
                document.getElementById('fix-section').classList.add('d-none');
                
                // Clean up files when the page is closed or refreshed
                window.addEventListener('beforeunload', function() {
                    fetch('/api/cleanup', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            file_paths: [filePath, data.output_path]
                        })
                    });
                });
            } else {
                // Show error
                resultBox.classList.add('result-error');
                resultBox.classList.remove('result-success');
                
                let resultContent = `
                    <div class="alert alert-danger">
                        <strong>Error:</strong> ${data.message}
                    </div>
                `;
                
                document.getElementById('result-content').innerHTML = resultContent;
                document.getElementById('fix-section').classList.add('d-none');
            }
        })
        .catch(error => {
            // Hide loading spinner
            document.getElementById('loading').style.display = 'none';
            
            // Show error
            const resultBox = document.getElementById('result-box');
            resultBox.classList.remove('d-none');
            resultBox.classList.add('result-error');
            resultBox.classList.remove('result-success');
            
            let resultContent = `
                <div class="alert alert-danger">
                    <strong>Error:</strong> An error occurred while fixing your document.
                </div>
                <p>Please try again later.</p>
            `;
            
            document.getElementById('result-content').innerHTML = resultContent;
            document.getElementById('fix-section').classList.add('d-none');
            
            console.error('Error:', error);
        });
    }
});
