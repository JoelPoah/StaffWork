from flask import Flask, request, jsonify, render_template, send_file
import os
import tempfile
import uuid
from werkzeug.utils import secure_filename
import docx
from docx.shared import Pt

app = Flask(__name__)

# Configure upload folder
UPLOAD_FOLDER = '/tmp/font_checker_uploads'
ALLOWED_EXTENSIONS = {'docx'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class FontChecker:
    """A tool to check and fix font settings in Word documents."""
    
    def __init__(self, file_path, target_font="Times New Roman", target_size=14):
        """Initialize the FontChecker with the document path and target font settings."""
        self.file_path = file_path
        self.target_font = target_font
        self.target_size = target_size
        self.doc = None
        self.issues = []
        self.fixed_issues = []
        
    def load_document(self):
        """Load the document and return True if successful, False otherwise."""
        try:
            self.doc = docx.Document(self.file_path)
            return True
        except Exception as e:
            print(f"Error loading document: {e}")
            return False
    
    def check_document(self):
        """Check the document for font issues and return a report."""
        if not self.doc:
            if not self.load_document():
                return {"success": False, "message": "Failed to load document."}
        
        self.issues = []
        
        # Check document styles
        self._check_styles()
        
        # Check paragraphs
        self._check_paragraphs()
        
        # Check tables
        self._check_tables()
        
        # Generate report
        if not self.issues:
            return {
                "success": True,
                "meets_requirements": True,
                "message": f"Document meets the requirement: {self.target_font}, size {self.target_size}",
                "issues": []
            }
        else:
            return {
                "success": True,
                "meets_requirements": False,
                "message": f"Document does not meet the requirement: {self.target_font}, size {self.target_size}",
                "issues": self.issues,
                "issue_count": len(self.issues)
            }
    
    def _check_styles(self):
        """Check document styles for font issues."""
        for style in self.doc.styles:
            if hasattr(style, 'font') and style.font:
                if style.font.name and style.font.name != self.target_font:
                    self.issues.append(f"Style '{style.name}' uses font '{style.font.name}' instead of '{self.target_font}'")
                
                if style.font.size and style.font.size / 12.0 != self.target_size:
                    size_pt = style.font.size / 12.0
                    self.issues.append(f"Style '{style.name}' uses font size {size_pt} instead of {self.target_size}")
    
    def _check_paragraphs(self):
        """Check paragraphs for font issues."""
        for i, paragraph in enumerate(self.doc.paragraphs):
            if not paragraph.text.strip():
                continue
                
            for run in paragraph.runs:
                if not run.text.strip():
                    continue
                    
                if run.font.name and run.font.name != self.target_font:
                    self.issues.append(f"Text '{run.text[:20]}...' uses font '{run.font.name}' instead of '{self.target_font}'")
                
                if run.font.size and run.font.size / 12.0 != self.target_size:
                    size_pt = run.font.size / 12.0
                    self.issues.append(f"Text '{run.text[:20]}...' uses font size {size_pt} instead of {self.target_size}")
    
    def _check_tables(self):
        """Check tables for font issues."""
        for i, table in enumerate(self.doc.tables):
            for row_idx, row in enumerate(table.rows):
                for col_idx, cell in enumerate(row.cells):
                    for paragraph in cell.paragraphs:
                        if not paragraph.text.strip():
                            continue
                            
                        for run in paragraph.runs:
                            if not run.text.strip():
                                continue
                                
                            if run.font.name and run.font.name != self.target_font:
                                self.issues.append(f"Table {i+1}, Cell ({row_idx+1},{col_idx+1}): Text '{run.text[:20]}...' uses font '{run.font.name}' instead of '{self.target_font}'")
                            
                            if run.font.size and run.font.size / 12.0 != self.target_size:
                                size_pt = run.font.size / 12.0
                                self.issues.append(f"Table {i+1}, Cell ({row_idx+1},{col_idx+1}): Text '{run.text[:20]}...' uses font size {size_pt} instead of {self.target_size}")
    
    def fix_document(self, output_path=None):
        """Fix font issues in the document and save to output_path."""
        if not self.doc:
            if not self.load_document():
                return {"success": False, "message": "Failed to load document."}
        
        self.fixed_issues = []
        
        # Fix document styles
        self._fix_styles()
        
        # Fix paragraphs
        self._fix_paragraphs()
        
        # Fix tables
        self._fix_tables()
        
        # Save the document
        if not output_path:
            base, ext = os.path.splitext(self.file_path)
            output_path = f"{base}_fixed{ext}"
        
        try:
            self.doc.save(output_path)
            return {
                "success": True,
                "message": f"Fixed {len(self.fixed_issues)} issues",
                "fixed_issues": self.fixed_issues,
                "fixed_issues_count": len(self.fixed_issues),
                "output_path": output_path
            }
        except Exception as e:
            return {"success": False, "message": f"Error saving document: {e}"}
    
    def _fix_styles(self):
        """Fix font issues in document styles."""
        for style in self.doc.styles:
            if hasattr(style, 'font') and style.font:
                if style.font.name != self.target_font:
                    old_font = style.font.name or "Default"
                    style.font.name = self.target_font
                    self.fixed_issues.append(f"Changed style '{style.name}' font from '{old_font}' to '{self.target_font}'")
                
                if style.font.size is None or style.font.size / 12.0 != self.target_size:
                    old_size = style.font.size / 12.0 if style.font.size else "Default"
                    style.font.size = Pt(self.target_size)
                    self.fixed_issues.append(f"Changed style '{style.name}' font size from {old_size} to {self.target_size}")
    
    def _fix_paragraphs(self):
        """Fix font issues in paragraphs."""
        for paragraph in self.doc.paragraphs:
            if not paragraph.text.strip():
                continue
                
            for run in paragraph.runs:
                if not run.text.strip():
                    continue
                    
                if run.font.name != self.target_font:
                    old_font = run.font.name or "Default"
                    run.font.name = self.target_font
                    self.fixed_issues.append(f"Changed text '{run.text[:20]}...' font from '{old_font}' to '{self.target_font}'")
                
                if run.font.size is None or run.font.size / 12.0 != self.target_size:
                    old_size = run.font.size / 12.0 if run.font.size else "Default"
                    run.font.size = Pt(self.target_size)
                    self.fixed_issues.append(f"Changed text '{run.text[:20]}...' font size from {old_size} to {self.target_size}")
    
    def _fix_tables(self):
        """Fix font issues in tables."""
        for i, table in enumerate(self.doc.tables):
            for row_idx, row in enumerate(table.rows):
                for col_idx, cell in enumerate(row.cells):
                    for paragraph in cell.paragraphs:
                        if not paragraph.text.strip():
                            continue
                            
                        for run in paragraph.runs:
                            if not run.text.strip():
                                continue
                                
                            if run.font.name != self.target_font:
                                old_font = run.font.name or "Default"
                                run.font.name = self.target_font
                                self.fixed_issues.append(f"Changed table {i+1}, cell ({row_idx+1},{col_idx+1}): text '{run.text[:20]}...' font from '{old_font}' to '{self.target_font}'")
                            
                            if run.font.size is None or run.font.size / 12.0 != self.target_size:
                                old_size = run.font.size / 12.0 if run.font.size else "Default"
                                run.font.size = Pt(self.target_size)
                                self.fixed_issues.append(f"Changed table {i+1}, cell ({row_idx+1},{col_idx+1}): text '{run.text[:20]}...' font size from {old_size} to {self.target_size}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/check', methods=['POST'])
def check_document():
    # Check if the post request has the file part
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'})
    
    file = request.files['file']
    
    # If user does not select file, browser also submits an empty part without filename
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No selected file'})
    
    if file and allowed_file(file.filename):
        # Generate a unique filename to avoid collisions
        unique_filename = str(uuid.uuid4()) + '_' + secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        
        # Save the uploaded file
        file.save(file_path)
        
        # Check the document
        checker = FontChecker(file_path)
        result = checker.check_document()
        
        # Add the file path to the result for later use
        result['file_path'] = file_path
        
        return jsonify(result)
    
    return jsonify({'success': False, 'message': 'Invalid file type. Only .docx files are allowed.'})

@app.route('/api/fix', methods=['POST'])
def fix_document():
    # Get the file path from the request
    data = request.get_json()
    if not data or 'file_path' not in data:
        return jsonify({'success': False, 'message': 'No file path provided'})
    
    file_path = data['file_path']
    
    # Check if the file exists
    if not os.path.exists(file_path):
        return jsonify({'success': False, 'message': 'File not found'})
    
    # Generate output path
    base, ext = os.path.splitext(file_path)
    output_path = f"{base}_fixed{ext}"
    
    # Fix the document
    checker = FontChecker(file_path)
    result = checker.fix_document(output_path)
    
    # Add the output file path to the result for download
    if result['success']:
        result['download_id'] = os.path.basename(output_path)
    
    return jsonify(result)

@app.route('/api/download/<download_id>', methods=['GET'])
def download_file(download_id):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], download_id)
    
    # Check if the file exists
    if not os.path.exists(file_path):
        return jsonify({'success': False, 'message': 'File not found'})
    
    # Get the original filename without the UUID prefix
    original_filename = '_'.join(download_id.split('_')[1:])
    if original_filename.endswith('_fixed.docx'):
        original_filename = original_filename[:-11] + '_fixed.docx'
    
    # Send the file for download
    return send_file(file_path, as_attachment=True, download_name=original_filename)

@app.route('/api/cleanup', methods=['POST'])
def cleanup_files():
    # Get the file paths from the request
    data = request.get_json()
    if not data or 'file_paths' not in data:
        return jsonify({'success': False, 'message': 'No file paths provided'})
    
    file_paths = data['file_paths']
    
    # Delete the files
    for file_path in file_paths:
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except Exception as e:
                print(f"Error deleting file {file_path}: {e}")
    
    return jsonify({'success': True, 'message': 'Files cleaned up'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
